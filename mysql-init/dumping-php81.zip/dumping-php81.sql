/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db`;

DROP TABLE IF EXISTS `cal_proes_cad`;
CREATE TABLE IF NOT EXISTS `cal_proes_cad` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `data` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DELETE FROM `cal_proes_cad`;

DROP TABLE IF EXISTS `candidato`;
CREATE TABLE IF NOT EXISTS `candidato` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DELETE FROM `candidato`;

DROP TABLE IF EXISTS `dados_pessoais`;
CREATE TABLE IF NOT EXISTS `dados_pessoais` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order` int NOT NULL DEFAULT '0',
  `nome` varchar(333) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `telefone` varchar(333) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(333) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `idade` int NOT NULL,
  `end_cep` int NOT NULL,
  `end_complemento` varchar(333) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1019 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DELETE FROM `dados_pessoais`;
INSERT INTO `dados_pessoais` (`id`, `order`, `nome`, `telefone`, `email`, `idade`, `end_cep`, `end_complemento`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1000, 12, 'Gustavo Hammes', '(21)980658545', 'hammes.gustavo@gmail.com', 46, 21710180, 'Rua Silva, 04, Engenho Novo', '2024-01-13 19:26:36', '2024-03-14 14:20:55', NULL),
	(1001, 19, 'Gustavo Hammes2', '(21)988558545', 'teste.gustavo@gmail.com', 46, 22710180, 'Rua Lito, 12, Engenho Novo', '2024-01-13 19:55:13', '2024-03-14 12:22:40', NULL),
	(1002, 18, 'Gustavo1 Hammes', '(21)980558545', 'buto.gustavo@gmail.com', 46, 23710180, 'Rua Ginga, 94, Engenho Novo', '2024-01-13 20:25:50', '2024-03-14 12:22:40', NULL),
	(1003, 17, 'Gustavo Hammes3', '(21)980558544', 'sistema1.gustavo@gmail.com', 46, 24710180, 'Rua Logo, 73, Engenho Novo', '2024-01-13 20:27:03', '2024-03-14 12:22:40', NULL),
	(1004, 16, 'Nome e Sobrenome', '(21)980558546', 'digital.gustavo@gmail.com', 46, 25710180, 'Rua Titulo, 11, Engenho Novo', '2024-01-20 13:12:29', '2024-03-14 12:22:40', NULL),
	(1005, 1, 'Nome e Sobrenome 2', '(21)950558545', 'tudo.gustavo@gmail.com', 46, 26710180, 'Rua Julio, 78, Engenho Novo', '2024-01-20 13:12:57', '2024-03-14 14:20:57', NULL),
	(1006, 15, 'Nome e Sobrenome 3', '(21)980551545', 'vida.gustavo@gmail.com', 46, 27710180, 'Rua Maria, 67, Engenho Novo', '2024-01-20 13:13:03', '2024-03-14 14:20:55', NULL),
	(1007, 14, 'Nome e Sobrenome 4', '(21)980518545', 'digital.gustavo@gmail.com', 46, 28710180, 'Rua Cipo, 89, Engenho Novo', '2024-01-20 13:13:31', '2024-03-14 14:20:55', NULL),
	(1008, 13, 'Nome e Sobrenome 5', '(21)980558541', 'lucas.gustavo@gmail.com', 46, 29710180, 'Rua Cachorro, 10, Engenho Novo', '2024-01-20 13:13:37', '2024-03-14 14:20:55', NULL),
	(1009, 8, 'Nome e Sobrenome 6', '(21)980558543', 'comunica.gustavo@gmail.com', 46, 20710181, 'Rua Raça, 12, Engenho Novo', '2024-01-20 13:13:44', '2024-03-14 14:39:35', NULL),
	(1010, 2, 'Nome e Sobrenome 7', '(21)980578545', 'rick.gustavo@gmail.com', 46, 20710182, 'Rua Lobo, 67, Engenho Novo', '2024-01-20 13:13:54', '2024-03-14 14:20:57', NULL),
	(1011, 3, 'Nome e Sobrenome 8', '(21)980558545', 'detel.gustavo@gmail.com', 46, 20710183, 'Rua Tio, 45, Engenho Novo', '2024-01-20 13:14:41', '2024-03-14 14:39:35', NULL),
	(1012, 4, 'Nome e Sobrenome 8', '(21)980358545', 'info.gustavo@gmail.com', 46, 20710184, 'Rua Cria, 95, Engenho Novo', '2024-01-20 13:14:53', '2024-03-14 14:39:35', NULL),
	(1013, 5, 'Nome e Sobrenome 9', '(21)980553545', 'sistema2.gustavo@gmail.com', 46, 20710185, 'Rua Tiro, 45, Engenho Novo', '2024-01-20 13:17:15', '2024-03-14 14:39:35', NULL),
	(1014, 6, 'Nome e Sobrenome 10', '(21)983558545', 'fera.gustavo@gmail.com', 46, 20710186, 'Rua Loja, 85, Engenho Novo', '2024-01-20 13:17:25', '2024-03-14 14:39:35', NULL),
	(1015, 11, 'Gustavo Hammes 4', '(21)980557545', 'melo.gustavo@gmail.com', 46, 20710111, 'Rua Teste, 75, Engenho Novo', '2024-02-05 14:49:06', '2024-03-14 14:39:35', NULL),
	(1016, 10, 'Gustavo Hammes 5', '(21)980528545', 'silva.gustavo@gmail.com', 46, 20710122, 'Rua Teste, 95, Engenho Novo', '2024-02-05 14:50:25', '2024-03-14 14:39:35', NULL),
	(1017, 9, 'Nome Completo', '(21)999977777', 'email@servidor.com', 46, 20710133, 'Rua Lago, 49, Eng Novo, Rio de Janeiro, RJ.', '2024-02-05 14:59:14', '2024-03-14 14:39:35', NULL),
	(1018, 7, 'Gustavo Hammes 6', '(21)980598545', 'lobo.gustavo@gmail.com', 46, 20710144, 'Rua Cipo, 99, Engenho Novo', '2024-02-05 15:01:39', '2024-03-14 14:39:35', NULL);

DROP TABLE IF EXISTS `proes_user`;
CREATE TABLE IF NOT EXISTS `proes_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `cpf` varchar(300) DEFAULT NULL,
  `cpf_validation` enum('Y','N') DEFAULT NULL,
  `mail` varchar(300) DEFAULT NULL,
  `celhpone` varchar(300) DEFAULT NULL,
  `token` varchar(300) DEFAULT NULL,
  `created_at` datetime DEFAULT (now()),
  `updated_at` datetime DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DELETE FROM `proes_user`;
INSERT INTO `proes_user` (`id`, `name`, `cpf`, `cpf_validation`, `mail`, `celhpone`, `token`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Gustavo de Melo Silva', '07622959789', 'Y', 'mail.gustavo@habilidade.com', '21980888545', '170795', '2024-02-14 21:20:46', '2024-03-14 15:38:49', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
